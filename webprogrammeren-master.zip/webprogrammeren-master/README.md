
1. [Presentatie les 1](http://rvessen.home.xs4all.nl/les1.pptx)
2. [Presentatie les 2](http://rvessen.home.xs4all.nl/les2.pptx)
3. [Presentatie les 3](http://rvessen.home.xs4all.nl/les3.pptx)
